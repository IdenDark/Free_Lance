<div v-if="page === 'client'" class="flex min-h-screen page-enter">
    <!-- Sidebar -->
    <aside class="sidebar w-64 fixed top-0 left-0 h-full border-r border-border flex flex-col" style="background:#13131A;">
      <div class="p-6 border-b border-border">
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
            <span class="font-display font-800 text-ink text-sm">F</span>
          </div>
          <span class="font-display font-700">FreelanceHub</span>
        </div>
      </div>
      <div class="p-4 border-b border-border">
        <div class="flex items-center gap-3 p-3">
          <div class="avatar w-10 h-10 text-sm text-ink" style="background:#C8F53E;">SM</div>
          <div>
            <div class="font-display font-600 text-sm">Sarah Mitchell</div>
            <div class="text-muted text-xs">Client Account</div>
          </div>
        </div>
      </div>
      <nav class="p-4 flex-1 space-y-1">
        <div v-for="item in clientNav" :key="item.key"
          @click="clientTab=item.key"
          :class="['sidebar-item cursor-pointer px-3 py-2.5 flex items-center gap-3 text-sm', clientTab===item.key?'active':'text-muted']">
          <span v-html="item.icon" class="w-5 h-5 flex-shrink-0"></span>
          <span>{{ item.label }}</span>
          <span v-if="item.badge" class="ml-auto badge badge-pending text-xs">{{ item.badge }}</span>
        </div>
      </nav>
      <div class="p-4 border-t border-border">
        <button @click="page='landing'" class="sidebar-item w-full px-3 py-2.5 flex items-center gap-3 text-sm text-muted cursor-pointer">
          <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
          <span>Sign Out</span>
        </button>
      </div>
    </aside>

    <!-- Main -->
    <main class="main-content flex-1 ml-64 min-h-screen">
      <!-- Topbar -->
      <div class="sticky top-0 z-10 glass border-b border-border px-8 py-4 flex items-center justify-between">
        <div>
          <h1 class="font-display font-700 text-lg">{{ clientNavLabel }}</h1>
          <p class="text-muted text-xs">Saturday, February 21, 2026</p>
        </div>
        <div class="flex items-center gap-3">
          <button class="relative w-9 h-9 rounded-lg border border-border flex items-center justify-center text-muted hover:text-soft transition-colors">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
            <span class="absolute -top-1 -right-1 w-4 h-4 bg-accent rounded-full flex items-center justify-center text-ink font-600" style="font-size:9px;">3</span>
          </button>
          <button @click="showPostJob=true" class="btn-primary text-sm px-4 py-2">+ Post Job</button>
        </div>
      </div>

      <div class="p-8">

        <!-- OVERVIEW TAB -->
        <div v-if="clientTab==='overview'" class="page-enter space-y-8">
          <!-- Stats -->
          <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div v-for="s in clientStats" :key="s.label" class="stat-card rounded-2xl p-5 border border-border">
              <div class="flex items-center justify-between mb-4">
                <span class="text-muted text-xs font-500">{{ s.label }}</span>
                <div class="w-8 h-8 rounded-lg flex items-center justify-center" :style="`background:${s.color}15`">
                  <span v-html="s.icon" :style="`color:${s.color}`"></span>
                </div>
              </div>
              <div class="font-display font-700 text-2xl">{{ s.value }}</div>
              <div class="text-xs mt-1" :style="`color:${s.color}`">{{ s.change }}</div>
            </div>
          </div>

          <!-- Recent Jobs + Activity -->
          <div class="grid lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 rounded-2xl border border-border p-6" style="background:#1A1A24;">
              <div class="flex items-center justify-between mb-5">
                <h3 class="font-display font-600">Active Job Posts</h3>
                <button @click="clientTab='jobs'" class="text-accent text-xs hover:underline">View All</button>
              </div>
              <div class="space-y-3">
                <div v-for="job in activeJobs" :key="job.id" class="flex items-center justify-between p-4 rounded-xl hover:bg-white/5 transition-colors cursor-pointer border border-border">
                  <div>
                    <div class="font-500 text-sm">{{ job.title }}</div>
                    <div class="text-muted text-xs mt-0.5">{{ job.apps }} applicants · Posted {{ job.date }}</div>
                  </div>
                  <div class="flex items-center gap-3">
                    <span :class="'badge badge-'+job.status">{{ job.statusLabel }}</span>
                    <button @click="clientTab='applications'" class="text-muted hover:text-soft text-xs transition-colors">Review →</button>
                  </div>
                </div>
              </div>
            </div>
            <div class="rounded-2xl border border-border p-6" style="background:#1A1A24;">
              <h3 class="font-display font-600 mb-5">Recent Activity</h3>
              <div class="space-y-4">
                <div v-for="a in recentActivity" :key="a.id" class="flex items-start gap-3">
                  <div class="w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center" :style="`background:${a.color}15`">
                    <span v-html="a.icon" :style="`color:${a.color};font-size:14px`"></span>
                  </div>
                  <div>
                    <p class="text-xs text-soft leading-snug">{{ a.text }}</p>
                    <p class="text-muted text-xs mt-0.5">{{ a.time }}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- JOBS TAB -->
        <div v-if="clientTab==='jobs'" class="page-enter">
          <div class="flex items-center gap-4 mb-6">
            <input type="text" placeholder="Search job posts..." class="max-w-xs" v-model="jobSearch"/>
            <select class="max-w-xs"><option>All Status</option><option>Open</option><option>In Progress</option><option>Completed</option></select>
            <button @click="showPostJob=true" class="btn-primary ml-auto text-sm px-4 py-2">+ Post New Job</button>
          </div>
          <div class="grid gap-4">
            <div v-for="job in filteredClientJobs" :key="job.id"
              class="card-hover rounded-2xl border border-border p-6 flex flex-col md:flex-row md:items-center gap-4" style="background:#1A1A24;">
              <div class="flex-1">
                <div class="flex items-center gap-3 mb-2">
                  <h3 class="font-display font-600">{{ job.title }}</h3>
                  <span :class="'badge badge-'+job.status">{{ job.statusLabel }}</span>
                </div>
                <p class="text-muted text-sm mb-3">{{ job.desc }}</p>
                <div class="flex flex-wrap gap-2">
                  <span v-for="tag in job.tags" :key="tag" class="badge" style="background:#2A2A38;color:#9090A8;border:none;font-size:11px;">{{ tag }}</span>
                </div>
              </div>
              <div class="flex flex-col items-end gap-2 min-w-max">
                <div class="font-display font-700 text-accent">{{ job.budget }}</div>
                <div class="text-muted text-xs">{{ job.apps }} applicants</div>
                <div class="flex gap-2 mt-2">
                  <button @click="clientTab='applications'" class="btn-outline text-xs px-3 py-1.5">View Apps</button>
                  <button class="text-muted hover:text-soft transition-colors text-xs px-2">Edit</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- APPLICATIONS TAB -->
        <div v-if="clientTab==='applications'" class="page-enter">
          <div class="rounded-2xl border border-border overflow-hidden" style="background:#1A1A24;">
            <div class="p-6 border-b border-border flex items-center justify-between">
              <h3 class="font-display font-600">Incoming Applications</h3>
              <div class="flex gap-2">
                <span class="badge badge-pending">8 New</span>
              </div>
            </div>
            <div class="divide-y divide-border">
              <div v-for="app in applications" :key="app.id" class="p-6 hover:bg-white/5 transition-colors">
                <div class="flex flex-col md:flex-row md:items-start gap-4">
                  <div class="avatar w-12 h-12 text-sm flex-shrink-0 text-ink font-700" :style="`background:${app.color}`">{{ app.initials }}</div>
                  <div class="flex-1">
                    <div class="flex flex-col md:flex-row md:items-center gap-2 mb-1">
                      <span class="font-display font-600">{{ app.name }}</span>
                      <span class="text-muted text-xs">· Applied for <span class="text-soft">{{ app.job }}</span></span>
                      <span :class="'badge badge-'+app.status+' ml-auto'">{{ app.statusLabel }}</span>
                    </div>
                    <p class="text-muted text-sm mb-3">{{ app.summary }}</p>
                    <div class="flex flex-wrap gap-2 mb-3">
                      <span v-for="tag in app.skills" :key="tag" class="badge" style="background:#2A2A38;color:#9090A8;border:none;font-size:11px;">{{ tag }}</span>
                    </div>
                    <div class="flex items-center gap-4 text-xs text-muted">
                      <span>⭐ {{ app.rating }} rating</span>
                      <span>{{ app.projects }} projects completed</span>
                      <span class="font-display font-600 text-accent">{{ app.rate }}</span>
                    </div>
                  </div>
                  <div class="flex gap-2 flex-shrink-0">
                    <button @click="hireFreelancer(app)" class="btn-primary text-xs px-4 py-2">Hire</button>
                    <button class="btn-outline text-xs px-3 py-2">View Profile</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- PROJECTS TAB -->
        <div v-if="clientTab==='projects'" class="page-enter space-y-4">
          <div v-for="proj in projects" :key="proj.id" class="rounded-2xl border border-border p-6" style="background:#1A1A24;">
            <div class="flex flex-col md:flex-row md:items-start gap-4 mb-5">
              <div class="flex-1">
                <div class="flex items-center gap-3 mb-1">
                  <h3 class="font-display font-600">{{ proj.title }}</h3>
                  <span :class="'badge badge-'+proj.status">{{ proj.statusLabel }}</span>
                </div>
                <p class="text-muted text-sm">Freelancer: <span class="text-soft">{{ proj.freelancer }}</span> · Due {{ proj.due }}</p>
              </div>
              <div class="text-right">
                <div class="font-display font-600 text-accent">{{ proj.budget }}</div>
                <div class="text-muted text-xs">Fixed Price</div>
              </div>
            </div>
            <div class="mb-3">
              <div class="flex items-center justify-between mb-1.5">
                <span class="text-xs text-muted">Progress</span>
                <span class="text-xs font-600 text-accent">{{ proj.progress }}%</span>
              </div>
              <div class="progress-bar h-2">
                <div class="progress-fill h-full" :style="`width:${proj.progress}%`"></div>
              </div>
            </div>
            <div class="flex items-center justify-between mt-4">
              <div class="flex gap-2">
                <span v-for="m in proj.milestones" :key="m" class="badge" :class="proj.progress >= 80 ? 'badge-completed' : 'badge-progress'" style="font-size:11px;">{{ m }}</span>
              </div>
              <button class="btn-outline text-xs px-3 py-1.5">Message Freelancer</button>
            </div>
          </div>
        </div>

      </div>
    </main>
  </div>